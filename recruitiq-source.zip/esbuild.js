import esbuild from "esbuild-linux-64";
export default esbuild;
