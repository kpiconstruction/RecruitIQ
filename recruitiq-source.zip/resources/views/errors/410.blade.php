@extends('errors::minimal')

@section('title', __('Link Expired'))
@section('code', '410')
@section('message', 'Link Expired')
