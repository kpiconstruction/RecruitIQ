import './bootstrap';
import Clipboard from "@ryangjchandler/alpine-clipboard"

Alpine.plugin(Clipboard)
