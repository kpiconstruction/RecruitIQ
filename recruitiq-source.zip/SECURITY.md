# Security Policy

## Supported Versions

| Version | Supported |
|---------| ------------------ |
| 1.x     | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability within Filament, please email Josie Darang via [hypernate1@gmail.com](mailto:hypernate1@gmail.com). All security vulnerabilities will be promptly addressed.
