<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('quick-create-menu');

$__html = app('livewire')->mount($__name, $__params, 'lw-841986608-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH /home/act/repositories/RecruitIQ/storage/framework/views/2569291205b2e45474e869c401553c4d.blade.php ENDPATH**/ ?>