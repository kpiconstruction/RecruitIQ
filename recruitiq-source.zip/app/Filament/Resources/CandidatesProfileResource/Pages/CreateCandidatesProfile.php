<?php

namespace App\Filament\Resources\CandidatesProfileResource\Pages;

use App\Filament\Resources\CandidatesProfileResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCandidatesProfile extends CreateRecord
{
    protected static string $resource = CandidatesProfileResource::class;
}
