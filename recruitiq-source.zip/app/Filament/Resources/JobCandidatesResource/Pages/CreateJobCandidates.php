<?php

namespace App\Filament\Resources\JobCandidatesResource\Pages;

use App\Filament\Resources\JobCandidatesResource;
use Filament\Resources\Pages\CreateRecord;

class CreateJobCandidates extends CreateRecord
{
    protected static string $resource = JobCandidatesResource::class;
}
