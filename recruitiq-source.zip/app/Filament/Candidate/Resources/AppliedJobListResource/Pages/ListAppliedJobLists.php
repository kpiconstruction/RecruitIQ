<?php

namespace App\Filament\Candidate\Resources\AppliedJobListResource\Pages;

use App\Filament\Candidate\Resources\AppliedJobListResource;
use Filament\Resources\Pages\ListRecords;

class ListAppliedJobLists extends ListRecords
{
    protected static string $resource = AppliedJobListResource::class;
}
