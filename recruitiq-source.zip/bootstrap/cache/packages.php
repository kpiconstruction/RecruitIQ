<?php return array (
  'abanoubnassem/filament-grecaptcha-field' => 
  array (
    'providers' => 
    array (
      0 => 'AbanoubNassem\\FilamentGRecaptchaField\\FilamentGRecaptchaFieldServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentGRecaptchaField' => 'AbanoubNassem\\FilamentGRecaptchaField\\Facades\\FilamentGRecaptchaField',
    ),
  ),
  'afatmustafa/filamentv3-turnstile' => 
  array (
    'providers' => 
    array (
      0 => 'Afatmustafa\\FilamentTurnstile\\FilamentTurnstileServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentTurnstile' => 'Afatmustafa\\FilamentTurnstile\\Facades\\FilamentTurnstile',
    ),
  ),
  'alfa6661/laravel-autonumber' => 
  array (
    'providers' => 
    array (
      0 => 'Alfa6661\\AutoNumber\\AutoNumberServiceProvider',
    ),
  ),
  'althinect/filament-spatie-roles-permissions' => 
  array (
    'providers' => 
    array (
      0 => 'Althinect\\FilamentSpatieRolesPermissions\\FilamentSpatieRolesPermissionsServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentSpatieRolesPermissions' => 'Althinect\\FilamentSpatieRolesPermissions\\FilamentSpatieRolesPermissionsFacade',
    ),
  ),
  'andreiio/blade-remix-icon' => 
  array (
    'providers' => 
    array (
      0 => 'AndreiIonita\\BladeRemixIcon\\BladeRemixIconServiceProvider',
    ),
  ),
  'anhskohbo/no-captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Anhskohbo\\NoCaptcha\\NoCaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'NoCaptcha' => 'Anhskohbo\\NoCaptcha\\Facades\\NoCaptcha',
    ),
  ),
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'awcodes/filament-quick-create' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentQuickCreate\\QuickCreateServiceProvider',
    ),
  ),
  'aymanalhattami/filament-slim-scrollbar' => 
  array (
    'providers' => 
    array (
      0 => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentSlimScrollbar' => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarFacade',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'codeat3/blade-ant-design-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeAntDesignIcons\\BladeAntDesignIconsServiceProvider',
    ),
  ),
  'codeat3/blade-carbon-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeCarbonIcons\\BladeCarbonIconsServiceProvider',
    ),
  ),
  'codeat3/blade-game-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeGameIcons\\BladeGameIconsServiceProvider',
    ),
  ),
  'codeat3/blade-iconpark' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeIconpark\\BladeIconparkServiceProvider',
    ),
  ),
  'codeat3/blade-phosphor-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladePhosphorIcons\\BladePhosphorIconsServiceProvider',
    ),
  ),
  'codeat3/blade-vaadin-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeVaadinIcons\\BladeVaadinIconsServiceProvider',
    ),
  ),
  'coderflex/laravel-turnstile' => 
  array (
    'providers' => 
    array (
      0 => 'Coderflex\\LaravelTurnstile\\LaravelTurnstileServiceProvider',
    ),
    'aliases' => 
    array (
      'LaravelTurnstile' => 'Coderflex\\LaravelTurnstile\\Facades\\LaravelTurnstile',
    ),
  ),
  'dominion-solutions/filament-captcha' => 
  array (
    'providers' => 
    array (
      0 => 'DominionSolutions\\FilamentCaptcha\\FilamentCaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentCaptcha' => 'DominionSolutions\\FilamentCaptcha\\Facades\\FilamentCaptcha',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'hasnayeen/themes' => 
  array (
    'providers' => 
    array (
      0 => 'Hasnayeen\\Themes\\ThemesServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'lab404/laravel-impersonate' => 
  array (
    'providers' => 
    array (
      0 => 'Lab404\\Impersonate\\ImpersonateServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'mallardduck/blade-lucide-icons' => 
  array (
    'providers' => 
    array (
      0 => 'MallardDuck\\LucideIcons\\BladeLucideIconsServiceProvider',
    ),
  ),
  'marjose123/filament-lockscreen' => 
  array (
    'providers' => 
    array (
      0 => 'lockscreen\\FilamentLockscreen\\FilamentLockscreenServiceProvider',
    ),
  ),
  'mews/captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Mews\\Captcha\\CaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'Captcha' => 'Mews\\Captcha\\Facades\\Captcha',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'njxqlus/filament-progressbar' => 
  array (
    'providers' => 
    array (
      0 => 'Njxqlus\\FilamentProgressbar\\FilamentProgressbarServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentProgressbar' => 'Njxqlus\\FilamentProgressbar\\Facades\\FilamentProgressbar',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'owenvoke/blade-fontawesome' => 
  array (
    'providers' => 
    array (
      0 => 'OwenVoke\\BladeFontAwesome\\BladeFontAwesomeServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
  'phpsa/filament-password-reveal' => 
  array (
    'providers' => 
    array (
      0 => 'Phpsa\\FilamentPasswordReveal\\FilamentPasswordRevealProvider',
    ),
  ),
  'rappasoft/laravel-authentication-log' => 
  array (
    'providers' => 
    array (
      0 => 'Rappasoft\\LaravelAuthenticationLog\\LaravelAuthenticationLogServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-settings' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelSettings\\LaravelSettingsServiceProvider',
    ),
  ),
  'stechstudio/filament-impersonate' => 
  array (
    'providers' => 
    array (
      0 => 'STS\\FilamentImpersonate\\FilamentImpersonateServiceProvider',
    ),
  ),
  'tapp/filament-authentication-log' => 
  array (
    'providers' => 
    array (
      0 => 'Tapp\\FilamentAuthenticationLog\\FilamentAuthenticationLogServiceProvider',
    ),
  ),
  'troccoli/blade-health-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Troccoli\\BladeHealthIcons\\BladeHealthIconsServiceProvider',
    ),
  ),
);